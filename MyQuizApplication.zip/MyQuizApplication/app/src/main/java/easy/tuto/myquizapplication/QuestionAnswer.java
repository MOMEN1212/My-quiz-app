package easy.tuto.myquizapplication;

public class QuestionAnswer {

    public static String question[] ={
            "what is the best university in turkey?",
            "what is the best subject of this semester?",
            "what is the best programming language?",
            "what is the best car company?"
    };

    public static String choices[][] = {
            {"Okan","Maltepe","Medipol","Marmara"},
            {"Mobile programming","Math1","physics","chemistry"},
            {"csharp","c++","python","Java"},
            {"BMW","Toyota","benz","Tesla"}
    };

    public static String correctAnswers[] = {
            "Okan",
            "Mobile programming",
            "python",
            "Tesla"
    };

}